#ifndef AQUEUE_VIEW_H_INCLUDED
#define AQUEUE_VIEW_H_INCLUDED
int view(void);
void Init_view(AQueue *Q);
void Destory_view(AQueue *Q);
void IsFull_view(AQueue *Q);
void IsEmpty_view(AQueue *Q);
void GetHead_view(AQueue *Q);
void Length_view(AQueue *Q);
void En_view(AQueue *Q);
void De_view(AQueue *Q);
void Clear_view(AQueue *Q);
void Traverse_view(AQueue *Q);

#endif // AQUEUE_VIEW_H_INCLUDED
