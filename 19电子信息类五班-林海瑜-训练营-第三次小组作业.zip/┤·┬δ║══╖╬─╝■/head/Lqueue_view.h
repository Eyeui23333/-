#ifndef LQUEUE_VIEW_H_INCLUDED
#define LQUEUE_VIEW_H_INCLUDED

int view(void);
void Init_view(LQueue *Q);
void Destory_view(LQueue *Q);
void IsEmpty_view(LQueue *Q);
void GetHead_view(LQueue *Q);
void Length_view(LQueue *Q);
void En_view(LQueue *Q);
void De_view(LQueue *Q);
void Clear_view(LQueue *Q);
void Traverse_view(LQueue *Q);

#endif // LQUEUE_VIEW_H_INCLUDED
