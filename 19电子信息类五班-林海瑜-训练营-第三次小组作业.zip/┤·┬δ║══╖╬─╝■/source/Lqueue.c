#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"../head/LQueue.h"
#include"../head/Lqueue_view.h"
void InitLQueue(LQueue *Q){
    Node *p = (Node *)malloc(sizeof(Node));
	if(p == NULL){
		printf("��ʼ���ڴ�ʧ�ܣ�");
		return;
	}
    printf("****************************\n");
    printf("��������Ҫ�����Ķ��е����ͣ�\n");
    printf("1.char\n");
    printf("2.double\n");
    printf("3.int\n");
    printf("****************************\n");
    int temp;
    while(scanf("%d",&temp) != 1 || temp < 1 || temp >3){
        printf("��������ȷ��������~\n");
        fflush(stdin);
    }
    switch(temp)
    {
    case 1:
        Q->length = sizeof(char);break;
    case 2:
        Q->length = sizeof(double);break;
    case 3:
        Q->length = sizeof(int);break;
    }
    fflush(stdin);
    p->next = NULL;
    Q->front = p;
    Q->rear = p;
	printf("��ʼ���ɹ���");
}

void DestoryLQueue(LQueue *Q){
    ClearLQueue(Q);
    free(Q->front);
    free(Q->rear);
	Q->front = NULL;
	Q->rear = NULL;
}

Status IsEmptyLQueue(const LQueue *Q){
    return (Q->front == Q->rear? TRUE: FALSE);
}

Status GetHeadLQueue(LQueue *Q, void *e){
    if(IsEmptyLQueue(Q))
    return FALSE;
    memcpy(e,Q->front->next->data,Q->length);
    return TRUE;
}

int LengthLQueue(LQueue *Q){
    int len;
    Node *p = (Node *)malloc(sizeof(Node));
    p = Q->front;
    for(len = 0;p != Q->rear;len++){
        p = p->next;
    }
    return len;
}

Status EnLQueue(LQueue *Q, void *data){
    Node *p = (Node *)malloc(sizeof(Node));
    if(p == NULL)
        return FALSE;
    p->data = (void *)malloc(sizeof(Q->length));
    if(p->data == NULL)
        return FALSE;
    memcpy(p->data,data,Q->length);
    p->next = NULL;
    Q->rear->next = p;//��P�������ϵ
    Q->rear = p;//�ٽ�rear����
    return TRUE;
}

Status DeLQueue(LQueue *Q){
    if(IsEmptyLQueue(Q))
        return FALSE;
    Node *p = (Node *)malloc(sizeof(Node));//�½���ɾ����ʱ����ͷ�
    p = Q->front->next;
    Q->front->next = p->next;
    if(Q->front->next == NULL)
       Q->rear = Q->front ;//ֻʣһ���ڵ�ʱ���轫rear��front��ϵ
    free(p);
    return TRUE;
}

void ClearLQueue(LQueue *Q){
    Node *p,*q;
    Q->rear = Q->front;
    p = Q->front->next;
    while(p != NULL){
        q = p;//�½�q����pѭ��
        p = p->next;
        free(q);
    }
    free(p);
}

Status TraverseLQueue(const LQueue *Q, void (*foo)(void *q,int size)){
    if(IsEmptyLQueue(Q))
        return FALSE;
    Node *p = (void *)malloc(sizeof(Q->length));
    p = Q->front->next;
    while(p != NULL){
        foo(p->data,Q->length);
        p = p->next;
    }
    return TRUE;
}

void LPrint(void *q,int size){
    if(size == sizeof(double))
        printf("%lf",*(double *)q);
    if(size == sizeof(char))
        printf("%c",*(char *)q);
    if(size == sizeof (int))
        printf("%d",*(int *)q);
    printf(" ");
}
