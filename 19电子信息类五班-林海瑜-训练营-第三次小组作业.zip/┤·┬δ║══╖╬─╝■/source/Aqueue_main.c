#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"../head/AQueue.h"
#include"../head/Aqueue_view.h"

int main(){
    AQueue *Q;
    Q = NULL;
    Q = (AQueue*)malloc(sizeof(AQueue));
    for(int i = 0;i < MAXQUEUE; i++)
    Q->data[i] = NULL;
    int choice;
    while((choice = view()) != 11){

        switch(choice)
        {
        case 1:Init_view(Q);break;
        case 2:Destory_view(Q);break;
        case 3:IsFull_view(Q);break;
        case 4:IsEmpty_view(Q);break;
        case 5:GetHead_view(Q);break;
        case 6:Length_view(Q);break;
        case 7:En_view(Q);break;
        case 8:De_view(Q);break;
        case 9:Clear_view(Q);break;
        case 10:Traverse_view(Q);break;
        default: printf("��������ȷ��������~");break;//���û���õģ����Է�bug
        }
    }
    printf("�ټ���~");
    system("pause");
    return 0;
}
