#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"../head/LQueue.h"
#include"../head/Lqueue_view.h"
int main(){
    LQueue *Q = (LQueue*)malloc(sizeof(LQueue));
    Q->front = NULL;
    int choice;
    while((choice = view()) != 10){

        switch(choice)
        {
        case 1:Init_view(Q);break;
        case 2:Destory_view(Q);break;
        case 3:Traverse_view(Q);break;
        case 4:IsEmpty_view(Q);break;
        case 5:GetHead_view(Q);break;
        case 6:Length_view(Q);break;
        case 7:En_view(Q);break;
        case 8:De_view(Q);break;
        case 9:Clear_view(Q);break;
        default: printf("��������ȷ��������~");break;//���û���õģ����Է�bug
        }
    }
    printf("�ټ���~");
    system("pause");
    return 0;
}
