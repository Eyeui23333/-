#include <stdio.h>
#include <reg51.h>
#include <stdlib.h>
#include <intrins.h>
#include "../inc/all.h"
Tank AI_tank[4],my_tank;
Bullet bullet[10];
uint8  interval[12]= {1,1,1,1,1,1,1,1,1,1,1,1};
uint8 code level_info[MAX_LEVEL] = {-1,-1,2,2,2};
uint8 bul_num;      //�ӵ����
uint8 position = 0;     //λ�ü���
uint8 speed=14;      //��Ϸ�ٶ�,������
uint8 level=1;      //��Ϸ�ؿ���
uint8 score=0;      //��Ϸ����
uint8 remain_enemy; //ʣ�����(δ���ֵĵ���)
uint8 home_i;
uint8 brick_i;
uint8 steel_i;
uint8 AI_tank_i;

void design_all()
{
    uint8 i;
    while(1)
    {
        if(interval[0]++%speed==0)        //�ٶȵ�����
        {
            GameCheak();                  //��Ϸʤ�����
            BulletFly ( bullet );
            if(game_flag == 0)
            {		
								//game_over();
								num_code2[0] = 0x3F;
						    num_code2[1] = 0x3F;
								TR0 = 0;
								ET0 = 0;//��ʱ��0����ʱ
								second = 60;
								count = 0;
								isplay2(0);
								while(1){
									if(re == STOP){
										last_flag = 1;
										re = 0;
										break;
										}
									if(re == RIGHT){
										re = 0;
										break;
									}
								}
                break;
            }
            for(i=0 ; i<=3 ; i++)         //AI̹���ƶ�ѭ��
            {
                if(AI_tank[i].model==2 && interval[i+1]++%10==0) //�ĸ�̹���еĿ���̹�˵���ʹ�ü�����1,2,3,4
                    MoveAITank( & AI_tank[i]);
                if(AI_tank[i].model!=2 && AI_tank[i].model!=0 && interval[i+5]++%20==0) //�ĸ�̹���е�����̹�˵���ʹ�ü�����5,6,7,8
                    MoveAITank( & AI_tank[i]);
						
            }
            for(i=0; i<=3; i++)                                 //����AI̹�˲���
                if(AI_tank[i].alive==0 && AI_tank[i].revive<2 && interval[9]++%20==0)  //һ���з�̹��ÿ��ֻ��2����
                {
                    BuildAITank(& AI_tank[i] );     //����AI̹�ˣ����
                    break;                                      //ÿ��ѭ��ֻ����һ��̹��
                }
            for(i=0; i<=3; i++)
                if(AI_tank[i].alive)
                    BuildAIBullet(&AI_tank[i]);                 //AIshoot�Դ�int��������CD,��ʹ��main�е�CD interval
            if(my_tank.alive == 1 && interval[10]++%2 == 0)
            {

                keyboard ();


            }
            if(my_tank.alive==0  && my_tank.revive < MAX_LIFE)
                BuildMyTank( &my_tank );
        }
    }

}

void keyboard()
{
		if(re == 11){
			MoveMyTank( UP );
			MoveMyTank( UP );
			MoveMyTank( UP );
			MoveMyTank( UP );
			re = 0;
			return;
		}
		if(re == 22){
			MoveMyTank( LEFT );
			MoveMyTank( LEFT );
			MoveMyTank( LEFT );
			MoveMyTank( LEFT );
			//while(re != STOP);
			
						re = 0;
			return;
		}
		if(re == 33){
			MoveMyTank( RIGHT);
			MoveMyTank( RIGHT);
			MoveMyTank( RIGHT);
			MoveMyTank( RIGHT);
re = 0;
			return;
		}
		if(re == 44){
			MoveMyTank(DOWN);
			MoveMyTank(DOWN);
			MoveMyTank(DOWN);
			MoveMyTank(DOWN);
						re = 0;
			return;
		}
    if(re == UP){
				//delay(100);
        MoveMyTank( UP );
				re = 0;
		}
		
    if(re == LEFT){
			//delay(210);
        MoveMyTank( LEFT );
			re = 0;
		}
		
    if(re == DOWN){
			//delay(210);
        MoveMyTank( DOWN);
			re = 0;
		}
		
    if(re == RIGHT){
			//delay(210);
        MoveMyTank( RIGHT );
			re = 0;
				
		}			
    if(re == FIGHT){
        BuildBullet(my_tank);
				
				re = 0;
		}
    if(re == STOP)
    {
        re = 0;
				TR0 = 0;
				ET0 = 0;//��ʱ��0����ʱ
        while(re != STOP);
				TR0 = 1;
				ET0 = 1;//��ʱ��0����ʱ
        re = 0;
    }

}


void BuildAIBullet(Tank *tank)    
{

    uint8 big1,big2,smal1,smal2,i;
    if(tank->CD==200)
    {
        if(!(rand()%11))     //��ȴ������������ÿ����Ϸ��������10��֮һ�Ŀ��ܷ����ӵ�
        {
            BuildBullet(*tank);
            tank->CD=0;
        }
    }
    else
        tank->CD++;
    if(tank->CD >= 199)       //AIǿ�����֣�����ȴ����һ����Χ����ʹ��
    {
        if(tank->x == 92 )     //���̹���ڵײ�(���������)
        {
            if(tank->y < 28) //���ϼ��ϱ�
            {
                if(tank->direction==DOWN)  //̹�˷�����
                {
                    BuildBullet(*tank);     //�����ӵ�
                    tank->CD=0;
                }
            }
            else if(tank->y >48)
            {
                if(tank->direction==UP)   //̹�˷�����
                {
                    BuildBullet(*tank);     //�����ӵ�
                    tank->CD=0;
                }
            }
        }
        else if(tank->y==my_tank.y+1 || tank->y==my_tank.y || tank->y==my_tank.y-1 || tank->y==my_tank.y+2 || tank->y==my_tank.y-2 || tank->y==my_tank.y-3 || tank->y==my_tank.y+3)  //AI̹���ں�����"�ڿ�"��׼�ҵ�̹��
        {
            if((tank->direction==RIGHT && my_tank.x > tank->x) ||(tank->direction==LEFT && my_tank.x < tank->x))
            {
                //����AI���Ҳ����ҵ�̹����AI̹���ҷ�������AI�����ҵ�̹����AI��

                if(my_tank.x < tank->x)
                {
                    big1=tank->x;
                    smal1=my_tank.x;
                }
                else
                {
                    smal1=tank->x;
                    big1=my_tank.x;
                }
                for(i=smal1+8; i<=big1-8; i = i+8) //�ж�AI�ڿڵ�ֱ������̹�˼������ϰ�
                    if(find_brick(i,tank->y,tank->direction) != 0)      //�����ϰ�
                        break;
                if(i==big1)            //��i�ߵ�big˵�����ϰ�
                {
                    BuildBullet(*tank);     //�����ӵ�
                    tank->CD=0;
                }
            }
        }
        else if(tank->x==my_tank.x+1 || tank->x==my_tank.x || tank->x==my_tank.x-1 || tank->x==my_tank.x+2 || tank->x==my_tank.x-2 || tank->x==my_tank.x-3 || tank->x==my_tank.x+3) //AI̹���ں�����"�ڿ�"��׼�ҵ�̹��
        {
            if((tank->direction==DOWN && my_tank.y > tank->y )|| (tank->direction==UP && my_tank.y < tank->y))
            {
                //����AI���²����ҵ�̹����AI̹���·�����AI�����ҵ�̹����AI�Ϸ�

                if(my_tank.y < tank->y)
                {
                    big2=tank->y;
                    smal2=my_tank.y;
                }
                else
                {
                    smal2=tank->y;
                    big2=my_tank.y;
                }
                for(i=smal2+8; i<=big2-8; i = i+8) //�ж�AI�ڿڵ�ֱ������̹�˼������ϰ�
                    if(find_brick(tank->x,i,tank->direction) != 0)    
                        break;
                if(i==big2)   //��i�ߵ�big-1˵�����ϰ�
                {
                    BuildBullet(*tank);     //�����ӵ�
                    tank->CD=0;
                }
            }
        }
    }
}

void BuildBullet(Tank tank)  //�ӵ����䣨������,����ṹ��Tank,��������ı���ȫ�ֱ����ṹ��bullet
{
   
    switch(tank.direction)   
    {
    case UP    :
        bullet [bul_num].x = tank.x;
        bullet [bul_num].y = tank.y-8;
        bullet [bul_num].direction=1;
        break;
    case DOWN  :
        bullet [bul_num].x = tank.x;
        bullet [bul_num].y = tank.y+8;
        bullet [bul_num].direction=2;
        break;
    case LEFT  :
        bullet [bul_num].x = tank.x-8;
        bullet [bul_num].y = tank.y;
        bullet [bul_num].direction=3;
        break;
    case RIGHT :
        bullet [bul_num].x = tank.x+8;
        bullet [bul_num].y = tank.y;
        bullet [bul_num].direction=4;
        break;
    }
    bullet [bul_num].exist = 1;    
    bullet [bul_num].initial = 1;  //�ӵ����ڳ�����״̬
    bullet [bul_num].my=tank.my;   //������ҵ�̹�˷�����ӵ�bullet.my=1������Ϊ0
    bul_num++;
    if(bul_num==BULLET_NUM)        //����ӵ����������10�ţ���ô��ͷ��ʼ���
        bul_num=0;                
}


void BulletFly(Bullet bullet[BULLET_NUM]) //�ӵ��ƶ��ʹ��
{
    //����ȫ�ֱ���Bullet�ĸı�
    uint8 i,j,temp;
    for(i =0; i<BULLET_NUM; i++) //�����ӵ�����һ��
    {
        if(bullet [i].exist == 1)
        {
            if(bullet[i].x > 92)
                bullet[i].exist = 0;//��ֹԽ����Ļ���ʱ��ɾ����ʱ�򣬰Ѹ���Ļɾ��
        }
        if(bullet [i].exist == 1)
        {
            for(j=0; j< BULLET_NUM ; j++)
            {
                if(bullet [j].exist == 1 && j != i)
                {
                    if(bullet_check(bullet[i].x,bullet[i].y,bullet[i].direction,bullet[j].x,bullet[j].y,bullet[j].direction) == 1)
                    {
                        bullet [j].exist=0;
                        bullet [i].exist=0;
                        if(bullet[i].initial == 0)
                        {
                            switch(bullet [i].direction)//����仯��ԭ�����ӵ�
                            {
                            case UP    :
                                (bullet [i].y) = (bullet [i].y) + 8;
                                break;
                            case DOWN  :
                                (bullet [i].y) = (bullet [i].y) - 8;
                                break;
                            case LEFT  :
                                (bullet [i].x) = (bullet [i].x) + 8;
                                break;
                            case RIGHT :
                                (bullet [i].x) = (bullet [i].x) - 8;
                                break;
                            }
                            Clear_things(bullet[i].x,bullet[i].y);//ɾ��ԭ�����ӵ�
                            Clear_things(bullet[j].x,bullet[j].y);
                            break;
                        }
                        else
                        {
                            //���������ӵ���ʱ��δ����
                            Clear_things(bullet[j].x,bullet[j].y);
                            break;
                        }
                    }
                }
            }
            if(bullet[i].my == 1 && bullet[i].exist == 1)
            {
                if(find_AI(bullet[i].x,bullet[i].y,bullet[i].direction) == 1 || (bullet[i].y == AI_tank[0].y && bullet[i].x == AI_tank[0].x) || (bullet[i].y == AI_tank[1].y && bullet[i].x == AI_tank[1].x) || (bullet[i].y == AI_tank[2].y && bullet[i].x == AI_tank[2].x) || (bullet[i].y == AI_tank[3].y && bullet[i].x == AI_tank[3].x))
                {
                    if(bullet[i].initial == 0)
                    {
                        switch(bullet [i].direction)//����仯��ԭ�����ӵ�
                        {
                        case UP    :
                            (bullet [i].y) = (bullet [i].y) + 8;
                            break;
                        case DOWN  :
                            (bullet [i].y) = (bullet [i].y) - 8;
                            break;
                        case LEFT  :
                            (bullet [i].x) = (bullet [i].x) + 8;
                            break;
                        case RIGHT :
                            (bullet [i].x) = (bullet [i].x) - 8;
                            break;
                        }
                        Clear_things(bullet[i].x,bullet[i].y);//ɾ��ԭ�����ӵ�
                    }
                    if(AI_tank[AI_tank_i].model == 3)
                        AI_tank[AI_tank_i].model = 2;//���ı����������з�����δ��
                    else if(AI_tank[AI_tank_i].alive == 1)
                    {
                        AI_tank[AI_tank_i].alive = 0;//�ı�����������Ļ�ı�з�
                        Clear_things(AI_tank[AI_tank_i].x,AI_tank[AI_tank_i].y);
                    }
										AI_tank[AI_tank_i].x = 0;
										AI_tank[AI_tank_i].y = 0;
                    bullet [i].exist = 0;
										sound_pom();
                    score = score + 1;
                    display(score);

                }
            }
            if(bullet[i].my == 0 && bullet[i].exist == 1)
            {
                if(find_me(bullet[i].x,bullet[i].y,bullet[i].direction) == 1)
                {
                    my_tank.alive = 0;
                    if(bullet[i].initial == 0)
                    {
                        switch(bullet [i].direction)//����仯��ԭ�����ӵ�
                        {
                        case UP    :
                            (bullet [i].y) = (bullet [i].y) + 8;
                            break;
                        case DOWN  :
                            (bullet [i].y) = (bullet [i].y) - 8;
                            break;
                        case LEFT  :
                            (bullet [i].x) = (bullet [i].x) + 8;
                            break;
                        case RIGHT :
                            (bullet [i].x) = (bullet [i].x) - 8;
                            break;
                        }
                        Clear_things(bullet[i].x,bullet[i].y);
                    }
                    Clear_things(my_tank.x, my_tank.y);
                    bullet[i].exist=0;
                    my_tank.revive++;
										sound_pom();
										if(score != 0){
                    score = score - 1;
										}
                    display(score);
                    re_num(MAX_LIFE - my_tank.revive);
                }
                if(find_AI(bullet[i].x,bullet[i].y,bullet[i].direction) == 1)
                {
                    //AI�ӵ������Է������ӵ���Ч��ʧ
                    if(bullet[i].initial == 0)
                    {
                        switch(bullet [i].direction)//����仯��ԭ�����ӵ�
                        {
                        case UP    :
                            (bullet [i].y) = (bullet [i].y) + 8;
                            break;
                        case DOWN  :
                            (bullet [i].y) = (bullet [i].y) - 8;
                            break;
                        case LEFT  :
                            (bullet [i].x) = (bullet [i].x) + 8;
                            break;
                        case RIGHT :
                            (bullet [i].x) = (bullet [i].x) - 8;
                            break;
                        }
                        Clear_things(bullet[i].x,bullet[i].y);
                    }
                    bullet[i].exist = 0;
                }
            }
            if(bullet[i].exist == 1)
            {
                temp = find_brick(bullet[i].x,bullet[i].y,bullet[i].direction);
                if(temp == 1 )
                {
                    if(bullet[i].initial == 0)
                    {
                        switch(bullet [i].direction)//����仯��ԭ�����ӵ�
                        {
                        case UP    :
                            (bullet [i].y) = (bullet [i].y) + 8;
                            break;
                        case DOWN  :
                            (bullet [i].y) = (bullet [i].y) - 8;
                            break;
                        case LEFT  :
                            (bullet [i].x) = (bullet [i].x) + 8;
                            break;
                        case RIGHT :
                            (bullet [i].x) = (bullet [i].x) - 8;
                            break;
                        }
                        Clear_things(bullet[i].x,bullet[i].y);
                    }
                    bullet[i].exist = 0;
                    Clear_things(brick[brick_i][0], brick[brick_i][1]);
                    brick[brick_i][0]  = 0;
                    brick[brick_i][1]  = 0;
                }
                if(temp == 4)
                {
                    if(bullet[i].initial == 0)
                    {
                        switch(bullet [i].direction)//����仯��ԭ�����ӵ�
                        {
                        case UP    :
                            (bullet [i].y) = (bullet [i].y) + 8;
                            break;
                        case DOWN  :
                            (bullet [i].y) = (bullet [i].y) - 8;
                            break;
                        case LEFT  :
                            (bullet [i].x) = (bullet [i].x) + 8;
                            break;
                        case RIGHT :
                            (bullet [i].x) = (bullet [i].x) - 8;
                            break;
                        }
                        Clear_things(bullet[i].x,bullet[i].y);
                    }
                    Clear_things(home[home_i][0], home[home_i][1]);
                    home[home_i][0]  = 0;
                    home[home_i][1]  = 0;
                    bullet[i].exist=0;
                }
                if(temp == 3) //Խ��
                {
                    if(bullet[i].initial == 0)
                    {
                        switch(bullet [i].direction)//����仯��ԭ�����ӵ�
                        {
                        case UP    :
                            (bullet [i].y) = (bullet [i].y) + 8;
                            break;
                        case DOWN  :
                            (bullet [i].y) = (bullet [i].y) - 8;
                            break;
                        case LEFT  :
                            (bullet [i].x) = (bullet [i].x) + 8;
                            break;
                        case RIGHT :
                            (bullet [i].x) = (bullet [i].x) - 8;
                            break;
                        }
                        Clear_things(bullet[i].x,bullet[i].y);
                    }
                    bullet[i].exist=0;
                }
                if(temp == 2) //����
                {
                    if(bullet[i].initial == 0)
                    {
                        switch(bullet [i].direction)//����仯��ԭ�����ӵ�
                        {
                        case UP    :
                            (bullet [i].y) = (bullet [i].y) + 8;
                            break;
                        case DOWN  :
                            (bullet [i].y) = (bullet [i].y) - 8;
                            break;
                        case LEFT  :
                            (bullet [i].x) = (bullet [i].x) + 8;
                            break;
                        case RIGHT :
                            (bullet [i].x) = (bullet [i].x) - 8;
                            break;
                        }
                        Clear_things(bullet[i].x,bullet[i].y);
                    }
                    bullet[i].exist=0;
                }
                if(temp == 5)
                {/*
									if(bullet[i].initial ==1){
										if((bullet[i].x == home[0][0] && bullet[0].y == home[0][1] ){
											bullet[i].initial = 0;
											bullet
										if(bullet[i].x == home[1][0] && bullet[i].y == home[1][1] )
										if(bullet[i].x == home[2][0] && bullet[i].y == home[2][1] ) 
										if(bullet[i].x == home[3][0] && bullet[i].y == home[3][1])
										bullet[i].initial = 0;
										
										continue;
									}*/
                    if(bullet[i].initial == 0)
                    {
                        switch(bullet [i].direction)//����仯��ԭ�����ӵ�
                        {
                        case UP    :
                            (bullet [i].y) = (bullet [i].y) + 8;
                            break;
                        case DOWN  :
                            (bullet [i].y) = (bullet [i].y) - 8;
                            break;
                        case LEFT  :
                            (bullet [i].x) = (bullet [i].x) + 8;
                            break;
                        case RIGHT :
                            (bullet [i].x) = (bullet [i].x) - 8;
                            break;
                        }
                        Clear_things(bullet[i].x,bullet[i].y);
                    }
										game_over();
                    bullet[i].exist = 0;
                    game_flag = 0;
										sound();
                    
                }
                if(temp == 0)
                {
                    if(bullet[i].initial == 1)
                    {
                        Display_bullet(bullet[i].x,bullet[i].y);
                        switch(bullet [i].direction)                                      
                        {
                        case UP    :
                            (bullet [i].y) = (bullet [i].y) - 8;
                            break;
                        case DOWN  :
                            (bullet [i].y) = (bullet [i].y) + 8;
                            break;
                        case LEFT  :
                            (bullet [i].x) = (bullet [i].x) - 8;
                            break;
                        case RIGHT :
                            (bullet [i].x) = (bullet [i].x) + 8;
                            break;
                        }
                    }
                    else
                    {
                        switch(bullet [i].direction)//����仯��ԭ�����ӵ�
                        {
                        case UP    :
                            (bullet [i].y) = (bullet [i].y) + 8;
                            break;
                        case DOWN  :
                            (bullet [i].y) = (bullet [i].y) - 8;
                            break;
                        case LEFT  :
                            (bullet [i].x) = (bullet [i].x) + 8;
                            break;
                        case RIGHT :
                            (bullet [i].x) = (bullet [i].x) - 8;
                            break;
                        }
                        Clear_things(bullet[i].x,bullet[i].y);//ɾ��ԭ�����ӵ�
                        switch(bullet [i].direction)
                        {
                        case UP    :
                            (bullet [i].y) = (bullet [i].y) - 8;
                            break;
                        case DOWN  :
                            (bullet [i].y) = (bullet [i].y) + 8;
                            break;
                        case LEFT  :
                            (bullet [i].x) = (bullet [i].x) - 8;
                            break;
                        case RIGHT :
                            (bullet [i].x) = (bullet [i].x) + 8;
                            break;
                        }
                        Display_bullet(bullet[i].x,bullet[i].y);//��ӡ���ڵ��ӵ�
                        switch(bullet [i].direction)
                        {
                        case UP    :
                            (bullet [i].y) = (bullet [i].y) - 8;
                            break;
                        case DOWN  :
                            (bullet [i].y) = (bullet [i].y) + 8;
                            break;
                        case LEFT  :
                            (bullet [i].x) = (bullet [i].x) - 8;
                            break;
                        case RIGHT :
                            (bullet [i].x) = (bullet [i].x) + 8;
                            break;
                        }
                        //���ӵ�����仯�ˣ�����δ��ӡ����һ�ε��øú������ж��Ƿ��ӡ
                    }
                    if(bullet[i].initial == 1)
                        bullet[i].initial = 0;
                }
            }
        }
    }
}

void Initialize()
{
    uint8 i;
    remain_enemy=8;
		second = 60;
    my_tank.revive=0;  //�ҵ�̹�˸������Ϊ0
    re_num(MAX_LIFE - my_tank.revive);
    re_enemy(remain_enemy);
    position=0;
    bul_num=0;
    BuildMyTank( &my_tank);
    for(i=0; i<10; i++)   //�ӵ���ʼ��
    {
        bullet [i].exist=0;
        bullet [i].initial=0;
    }
    for(i=0; i<=3; i++)       //AI̹�˳�ʼ��
    {
        AI_tank [i].model =0;
        AI_tank [i].revive=0;
        AI_tank [i].alive=0;  //��ʼ��̹��ȫ�ǲ����ģ�BuildAITank()�Ὠ�����½���������̹��
        AI_tank [i].stop=0;

        AI_tank [i].my=0;
        AI_tank [i].CD=0;
    }
		TR0 = 1;
		ET0 = 1;//��ʱ��0����ʱ

}

void BuildAITank(Tank* AI_tank)   //ִ��һ�θú���ֻ����һ��̹��
{

    AI_tank->x= 4;
    AI_tank->y= 4 + 4 * position ;
    if(level == 3 && AI_tank->revive + 1 ==level_info[level-1])
    {
        AI_tank->model = 3;           //3Ϊfirm tank��ģ��(���)

    }
    else if(AI_tank->revive +1 ==level_info[level-1] && (level == 4 || level == 5))
    {
        AI_tank->model = 2;

    }
    else      //��̹ͨ��
    {
        AI_tank->model = 1;

    }
    AI_tank->alive = 1;       //̹�˱�Ϊ����
    AI_tank->direction = RIGHT ;  //������
    AI_tank->revive++;        //�������+1
    PrintTank(*AI_tank);
    position = position + 4;
    remain_enemy--;
    re_enemy(remain_enemy);
    if(position==16)          
        position = 0;

}



void MoveAITank(Tank* AI_tank) //AIר�ú������ú�����ҪΪAI��ǿ
{
    uint8 j;
    uint8 temp1,temp2;
    temp1 = AI_tank->x;
    temp2 = AI_tank->y;
    if(AI_tank->alive == 1)        
    {
        if(AI_tank->stop!=0)   //̹���Ƿ�ֹͣ�˶����жϣ���stop������Ϊ0
        {
            AI_tank->stop--;   //���̹�˱��غ�ֹͣ�˶�
            return;
        }
        if( !(rand()%23) )     //22��֮1�ĸ���ִ�з�������
        {
            AI_tank->direction = rand()%4+1;
            if( rand()%3 )     //�ڷ������ú���2��֮1�ĸ���ֹͣ�߶�3����ʱ��
            {
                AI_tank->stop=2;
                return;
            }
        }

        if(TankCheak (*AI_tank) == 0)    //���ǰ�����ϰ�����Խ��
        {
            //while(re != 0x0F);
            switch ( AI_tank->direction )
            {
            case UP   :
                AI_tank->y = AI_tank->y -8;
                break;  
            case DOWN :
                AI_tank->y = AI_tank->y+8;
                break; 
            case LEFT :
                AI_tank->x = AI_tank->x-8;
                break; 
            case RIGHT:
                AI_tank->x =  AI_tank->x+8;
                break;  
            }
        }
        else                     //ǰ�����ϰ�
        {

            if(!(rand()%4))      //3��֮1�ĸ�����ת
            {
                AI_tank->direction=rand()%4+1;
                AI_tank->stop=2; //��ת֮��ֹͣ�߶�3����ʱ��
                Clear_things(temp1, temp2);
                PrintTank(*AI_tank);
                return;
            }
            else                 //����3��֮2�ļ���ѡ����ȷ�ķ���
            {
                for(j=1; j<=4; j++)
                    if(TankCheak ( *AI_tank) == 0)
                        break;
                if(j==5)         //j==5˵����̹�����ܶ����ϰ���޷�ͨ��
                {
                    Clear_things(temp1, temp2);
                    PrintTank(*AI_tank);
                    return;     
                }
                while(TankCheak (*AI_tank) == 0)  
                    AI_tank->direction=(rand()%4+1); //���ϰ��򻻸����������
            }
        }
        Clear_things(temp1, temp2);
        PrintTank(*AI_tank);     //��ӡAI̹��
    }
}

void BuildMyTank (Tank* my_tank) //�����ҵ�̹��
{
    my_tank->x=92;
    my_tank->y=60;
    my_tank->stop=0;
    my_tank->direction=LEFT;
    my_tank->model=0;
    my_tank->alive=1;
    my_tank->my=1;
    my_tank->CD=7;
    PrintTank (*my_tank) ;   //��ӡ�ҵ�̹��
}

void MoveMyTank(uint8 turn )   //���ר�ú�����turnΪkeyboard�����������벻ͬ�����������Ĳ�ͬ��ֵ
{
    uint8 temp1,temp2;
    temp1 = my_tank.x;
    temp2 = my_tank.y;

    my_tank.direction= turn;                  //����������ķ���ֵ�����ҵ�̹�˷���ֵ
    if(TankCheak (my_tank) == 0)
    {
        Clear_things(my_tank.x,my_tank.y);
        switch (turn)
        {
        case UP   :
            my_tank.y = my_tank.y-8;
            break; 
        case DOWN :
            my_tank.y = my_tank.y+8;
            break;  
        case LEFT :
            my_tank.x = my_tank.x-8;
            break;  
        case RIGHT:
            my_tank.x = my_tank.x+8;
            break; 
        }
        PrintTank (my_tank);
    }
    else
    {
        Clear_things(my_tank.x,my_tank.y);
        PrintTank (my_tank);
    }
}

void GameCheak()
{
    if(remain_enemy<=0 && !AI_tank[0].alive && !AI_tank[1].alive && !AI_tank[2].alive && !AI_tank[3].alive )
    {sound();
        game_flag = 0;
				victory();
        
    }
    if(my_tank.revive>=MAX_LIFE)   //�ҵ�����ֵ(�������)ȫ������ MAX_LIFE
    {		sound();
			game_over();
        game_flag = 0;
        
        
    }
}