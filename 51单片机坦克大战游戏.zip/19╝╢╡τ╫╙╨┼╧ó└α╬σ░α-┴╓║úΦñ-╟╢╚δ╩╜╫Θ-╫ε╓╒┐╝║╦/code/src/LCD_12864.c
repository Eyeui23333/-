#include <stdio.h>
#include <reg51.h>
#include <stdlib.h>
#include <intrins.h>
#include "../inc/all.h"

void LCDdelay(unsigned int t)
{
	unsigned int i,j;
	for(i=0;i<t;i++);
	for(j=0;j<10;j++);
}
 

void init_lcd()
{
	LCDdelay(100);	
	LCDMcs=1;//�տ�ʼ�ر�����
	LCDScs=1;
	LCDdelay(100);
	WriteCmd(LCDLCDDisp_Off);	 //д��ʼ������
	WriteCmd(Page_Add+0);
	WriteCmd(Start_Line+0);
	WriteCmd(LCDCol_Add+0);
	WriteCmd(LCDLCDDisp_On);
}

void CleanAll(){
	unsigned char j,k;
	LCDMcs=0; //������������ʾ
	LCDScs=0;
 	WriteCmd(Page_Add+0);
 	WriteCmd(LCDCol_Add+0);
 	for(k=0;k<8;k++)//����ҳ��0-7����8ҳ
 	{
		WriteCmd(Page_Add+k); //ÿҳÿҳ����д
  		for(j=0;j<64;j++)  //ÿҳ����д32���������ֻ�64��ASCII�ַ�
		{
      		WriteCmd(LCDCol_Add+j);
					WriteData(0x00);//��������0-63����64�У�д�����ݣ��е�ַ�Զ���1
		}
	}
}

void CheckState()		
{
   unsigned char dat,DATA;//״̬��Ϣ���ж��Ƿ�æ��
   LCDDi=0; // ����\ָ��ѡ��D/I��RS��="L" ����ʾ DB7��DB0 Ϊ��ʾָ������ 
   LCDRW=1; //R/W="H" ��E="H"���ݱ�����DB7��DB0 
   do
   {
      DATA=0x00;
      LCDEnable=1;	//EN�½�Դ
	  LCDdelay(2);//��ʱ
	  dat=DATA;
      LCDEnable=0;
      dat=0x80 & dat; //������7λΪ0ʱ�ſɲ���(�б�busy�ź�)
    }
    while(!(dat==0x00));
}
	
void WriteData(unsigned char LCDDispdata)
{
    CheckState();//���LCD�Ƿ�æ
	LCDDi=1;
	LCDRW=0;
	P1=LCDDispdata;
	LCDdelay(2);
	LCDEnable=1;
	LCDdelay(2);
	LCDEnable=0;
}

void WriteCmd(uint8 cmdcode)
{
    CheckState();//���LCD�Ƿ�æ
	LCDDi=0;
	LCDRW=0;
	P1=cmdcode;		
	LCDdelay(2);
	LCDEnable=1;
	LCDdelay(2);
	LCDEnable=0;
}


void PrintTank(Tank tank){
	uint8 ucCol,temp;
	ucCol = tank.x-4;
	temp = (tank.y-4)/8;
	if(tank.model == 0){
		if(tank.direction == UP){
			DisplayByte(temp,ucCol,0xFF);
			DisplayByte(temp,ucCol+1,0xFF);
			DisplayByte(temp,ucCol+2,0x7C);
			DisplayByte(temp,ucCol+3,0x7F);
			DisplayByte(temp,ucCol+4,0x7F);
			DisplayByte(temp,ucCol+5,0x7C);
			DisplayByte(temp,ucCol+6,0xFF);
			DisplayByte(temp,ucCol+7,0xFF);
		}
		if(tank.direction == RIGHT){
			DisplayByte(temp,ucCol,0xC3);
			DisplayByte(temp,ucCol+1,0xFF);
			DisplayByte(temp,ucCol+2,0xFF);
			DisplayByte(temp,ucCol+3,0xFF);
			DisplayByte(temp,ucCol+4,0xFF);
			DisplayByte(temp,ucCol+5,0xFF);
			DisplayByte(temp,ucCol+6,0xDB);
			DisplayByte(temp,ucCol+7,0xDB);
		}
		if(tank.direction == DOWN){
			DisplayByte(temp,ucCol,0xFF);
			DisplayByte(temp,ucCol+1,0xFF);
			DisplayByte(temp,ucCol+2,0x3E);
			DisplayByte(temp,ucCol+3,0xFE);
			DisplayByte(temp,ucCol+4,0xFE);
			DisplayByte(temp,ucCol+5,0x3E);
			DisplayByte(temp,ucCol+6,0xFF);
			DisplayByte(temp,ucCol+7,0xFF);
		}
		if(tank.direction == LEFT){
			DisplayByte(temp,ucCol,0xDB);
			DisplayByte(temp,ucCol+1,0xDB);
			DisplayByte(temp,ucCol+2,0xFF);
			DisplayByte(temp,ucCol+3,0xFF);
			DisplayByte(temp,ucCol+4,0xFF);
			DisplayByte(temp,ucCol+5,0xFF);
			DisplayByte(temp,ucCol+6,0xFF);
			DisplayByte(temp,ucCol+7,0xC3);
		}
	}
	if(tank.model == 1){
		if(tank.direction == UP){
			DisplayByte(temp,ucCol,0xFF);
			DisplayByte(temp,ucCol+1,0xFC);
			DisplayByte(temp,ucCol+2,0xF8);
			DisplayByte(temp,ucCol+3,0x43);
			DisplayByte(temp,ucCol+4,0x43);
			DisplayByte(temp,ucCol+5,0xF8);
			DisplayByte(temp,ucCol+6,0xFC);
			DisplayByte(temp,ucCol+7,0xFF);
		}
		if(tank.direction == RIGHT){
			DisplayByte(temp,ucCol,0xE7);
			DisplayByte(temp,ucCol+1,0xFF);
			DisplayByte(temp,ucCol+2,0xE7);
			DisplayByte(temp,ucCol+3,0xE7);
			DisplayByte(temp,ucCol+4,0xE7);
			DisplayByte(temp,ucCol+5,0xC3);
			DisplayByte(temp,ucCol+6,0x99);
			DisplayByte(temp,ucCol+7,0x99);
		}
		if(tank.direction == DOWN){
			DisplayByte(temp,ucCol,0xFF);
			DisplayByte(temp,ucCol+1,0x3F);
			DisplayByte(temp,ucCol+2,0x1F);
			DisplayByte(temp,ucCol+3,0xC2);
			DisplayByte(temp,ucCol+4,0xC2);
			DisplayByte(temp,ucCol+5,0x1F);
			DisplayByte(temp,ucCol+6,0x3F);
			DisplayByte(temp,ucCol+7,0xEF);
		}
		if(tank.direction == LEFT){
			
			DisplayByte(temp,ucCol,0x99);
			DisplayByte(temp,ucCol+1,0x99);
			DisplayByte(temp,ucCol+2,0xC3);
			DisplayByte(temp,ucCol+3,0xE7);
			DisplayByte(temp,ucCol+4,0xE7);
			DisplayByte(temp,ucCol+5,0xE7);
			DisplayByte(temp,ucCol+6,0xFF);
			DisplayByte(temp,ucCol+7,0xE7);
		}
		
	}
	if(tank.model == 2){
		if(tank.direction == UP){
			DisplayByte(temp,ucCol,0xFF);
			DisplayByte(temp,ucCol+1,0x62);
			DisplayByte(temp,ucCol+2,0x30);
			DisplayByte(temp,ucCol+3,0xDF);
			DisplayByte(temp,ucCol+4,0xDF);
			DisplayByte(temp,ucCol+5,0x30);
			DisplayByte(temp,ucCol+6,0x62);
			DisplayByte(temp,ucCol+7,0xFF);
		}
		if(tank.direction == RIGHT){
			DisplayByte(temp,ucCol,0x99);
			DisplayByte(temp,ucCol+1,0xDB);
			DisplayByte(temp,ucCol+2,0xE7);
			DisplayByte(temp,ucCol+3,0xBD);
			DisplayByte(temp,ucCol+4,0x99);
			DisplayByte(temp,ucCol+5,0x99);
			DisplayByte(temp,ucCol+6,0xDB);
			DisplayByte(temp,ucCol+7,0x99);
		}
		if(tank.direction == DOWN){
			DisplayByte(temp,ucCol,0xFF);
			DisplayByte(temp,ucCol+1,0x46);
			DisplayByte(temp,ucCol+2,0x0C);
			DisplayByte(temp,ucCol+3,0xFB);
			DisplayByte(temp,ucCol+4,0xFB);
			DisplayByte(temp,ucCol+5,0x0C);
			DisplayByte(temp,ucCol+6,0x46);
			DisplayByte(temp,ucCol+7,0xFF);
		}
		if(tank.direction == LEFT){
			DisplayByte(temp,ucCol,0x99);
			DisplayByte(temp,ucCol+1,0xDB);
			DisplayByte(temp,ucCol+2,0x99);
			DisplayByte(temp,ucCol+3,0x99);
			DisplayByte(temp,ucCol+4,0xBD);
			DisplayByte(temp,ucCol+5,0xE7);
			DisplayByte(temp,ucCol+6,0xDB);
			DisplayByte(temp,ucCol+7,0x99);
		}
	}
	if(tank.model == 3){
		if(tank.direction == UP){
			DisplayByte(temp,ucCol,0xE7);
			DisplayByte(temp,ucCol+1,0x3C);
			DisplayByte(temp,ucCol+2,0xC6);
			DisplayByte(temp,ucCol+3,0xF3);
			DisplayByte(temp,ucCol+4,0xF3);
			DisplayByte(temp,ucCol+5,0xC6);
			DisplayByte(temp,ucCol+6,0x3C);
			DisplayByte(temp,ucCol+7,0xE7);
		}
		if(tank.direction == RIGHT){
			DisplayByte(temp,ucCol,0xBD);
			DisplayByte(temp,ucCol+1,0xBD);
			DisplayByte(temp,ucCol+2,0xDB);
			DisplayByte(temp,ucCol+3,0x5A);
			DisplayByte(temp,ucCol+4,0x42);
			DisplayByte(temp,ucCol+5,0xE7);
			DisplayByte(temp,ucCol+6,0xBD);
			DisplayByte(temp,ucCol+7,0x99);
		}
		if(tank.direction == DOWN){
			DisplayByte(temp,ucCol,0xE7);
			DisplayByte(temp,ucCol+1,0x3C);
			DisplayByte(temp,ucCol+2,0xC6);
			DisplayByte(temp,ucCol+3,0xF3);
			DisplayByte(temp,ucCol+4,0xF3);
			DisplayByte(temp,ucCol+5,0xC6);
			DisplayByte(temp,ucCol+6,0x3C);
			DisplayByte(temp,ucCol+7,0xE7);
		}
		if(tank.direction == LEFT){
			DisplayByte(temp,ucCol,0x99);
			DisplayByte(temp,ucCol+1,0xBD);
			DisplayByte(temp,ucCol+2,0xE7);
			DisplayByte(temp,ucCol+3,0x42);
			DisplayByte(temp,ucCol+4,0x5A);
			DisplayByte(temp,ucCol+5,0xDB);
			DisplayByte(temp,ucCol+6,0xBD);
			DisplayByte(temp,ucCol+7,0xBD);
		}
	}
}
void  Displaykuai(uint8 ucCol,uint8 ucPage,uint8 ucdata)//��ש�飬���Ա������
{
	uint8 temp;
	temp = ucPage;
	DisplayByte(temp,ucCol,ucdata);
	DisplayByte(temp,ucCol+1,ucdata);
	DisplayByte(temp,ucCol+2,ucdata);
	DisplayByte(temp,ucCol+3,ucdata);
	DisplayByte(temp,ucCol+4,ucdata);
	DisplayByte(temp,ucCol+5,ucdata);
	DisplayByte(temp,ucCol+6,ucdata);
	DisplayByte(temp,ucCol+7,ucdata);
}

		
void Clear_things(uint8 ucCol,uint8 ucPage){
	uint8 temp;
	temp = (ucPage - 4)/8;
	ucCol = ucCol - 4;
	DisplayByte(temp,ucCol,0x00);
	DisplayByte(temp,ucCol+1,0x00);
	DisplayByte(temp,ucCol+2,0x00);
	DisplayByte(temp,ucCol+3,0x00);
	DisplayByte(temp,ucCol+4,0x00);
	DisplayByte(temp,ucCol+5,0x00);
	DisplayByte(temp,ucCol+6,0x00);
	DisplayByte(temp,ucCol+7,0x00);
}
void  Display_bullet(uint8 ucCol,uint8 ucPage){
	uint8 temp;
	ucCol = ucCol - 4;
	temp = (ucPage - 4)/8;
	DisplayByte(temp,ucCol,0x18);
	DisplayByte(temp,ucCol+1,0x18);
	DisplayByte(temp,ucCol+2,0x18);
	DisplayByte(temp,ucCol+3,0xFF);
	DisplayByte(temp,ucCol+4,0xFF);
	DisplayByte(temp,ucCol+5,0x18);
	DisplayByte(temp,ucCol+6,0x18);
	DisplayByte(temp,ucCol+7,0x18);
	
}

void  choice_button(uint8 ucCol,uint8 ucPage){
	uint8 temp;
	ucCol = ucCol - 4;
	temp = (ucPage - 4)/8;
	DisplayByte(temp,ucCol,0xC0);
	DisplayByte(temp,ucCol+1,0xE0);
	DisplayByte(temp,ucCol+2,0xF0);
	DisplayByte(temp,ucCol+3,0xFC);
	DisplayByte(temp,ucCol+4,0xFC);
	DisplayByte(temp,ucCol+5,0xF0);
	DisplayByte(temp,ucCol+6,0xE0);
	DisplayByte(temp,ucCol+7,0xC0);
	
}

void DisplayByte(uint8 ucPage,uint8 ucCol,uint8 ucData){//��������
	uint8 i=Page_Add+ucPage;
	uint8 j=LCDCol_Add+ucCol%SINGLE_SCREEN_COL;
	if(ucCol/SINGLE_SCREEN_COL==0)
	{
		LCDMcs=0;															//ѡ������
		LCDScs=1;
	}
	else{
	LCDMcs=1;//ѡ������
	LCDScs=0;
	}

	WriteCmd(Page_Add);														//���ÿ�ʼ����
	WriteCmd(LCDCol_Add);														//���ÿ�ʼ����
	WriteCmd(i);
	WriteCmd(j);
	WriteData(ucData);
}
	
	

void Display_hz(uint8 page,uint8 column,uint8 code *ucData){//���ڷ�����Ч
	uint8 j=0,i=0;
	WriteCmd(Page_Add);														//���ÿ�ʼ����
	WriteCmd(LCDCol_Add);														//���ÿ�ʼ����
	for(j=0;j<2;j++)
	{
		WriteCmd(Page_Add+page+j);
		WriteCmd(LCDCol_Add+column);
		for(i=0;i<16;i++) 
			WriteData(ucData[16*j+i]);
	}
}

void Display_num(uint8 page,uint8 column,uint8 code *ucData){//���ڷ�����Ч
	uint8 j,i;
		WriteCmd(Page_Add);														//���ÿ�ʼ����
	WriteCmd(LCDCol_Add);														//���ÿ�ʼ����
	for(j=0;j<2;j++)
	{
		WriteCmd(Page_Add+page+j);
		WriteCmd(LCDCol_Add+column);
		for(i=0;i<4;i++) 
			WriteData(ucData[4*j+i]);
	}
}

void draw_two()
{
    uint8 i,j,k,f;
    j = 0;
    for(k=0; k<4; k++)
    {
        steel[k][0] = steel1[k][0];
        steel[k][1] = steel1[k][1];
    }
    for(f=0; f<8; f++)
    {
        brick[f][0] = brick1[f][0];
        brick[f][1] = brick1[f][1];
    }

    for(i=0; i<8; i++)
        Displaykuai(brick[i][j]-4,(brick[i][j+1]-4)/8,0xff);
    for(i=0; i<4; i++)
        Displaykuai(steel[i][j]-4,(steel[i][j+1]-4)/8,0xAA);
		sound();

}

void draw_one()
{		
    uint8 i,j,k,f;
    j = 0;
    for(k=0; k<4; k++)
    {
        steel[k][0] = steel2[k][0];
        steel[k][1] = steel2[k][1];
    }
    for(f=0; f<8; f++)
    {
        brick[f][0] = brick2[f][0];
        brick[f][1] = brick2[f][1];
    }
    for(i=0; i<8; i++)
        Displaykuai(brick[i][j]-4,(brick[i][j+1]-4)/8,0xff);
    for(i=0; i<4; i++)
        Displaykuai(steel[i][j]-4,(steel[i][j+1]-4)/8,0xAA);
		sound();
}

void draw_three()
{
    uint8 i,j,k,f;
    j = 0;
    for(k=0; k<4; k++)
    {
        steel[k][0] = steel3[k][0];
        steel[k][1] = steel3[k][1];
    }
    for(f=0; f<8; f++)
    {
        brick[f][0] = brick3[f][0];
        brick[f][1] = brick3[f][1];
    }
    for(i=0; i<8; i++)
        Displaykuai(brick[i][j]-4,(brick[i][j+1]-4)/8,0xff);
    for(i=0; i<4; i++)
        Displaykuai(steel[i][j]-4,(steel[i][j+1]-4)/8,0xAA);
sound();
}

void draw_home()
{
    uint8 i,k;
    for(k=0; k<6; k++)
    {
        home[k][0] = ho[k][0];
        home[k][1] = ho[k][1];
    }
    for(i=0; i<4; i++)
        Displaykuai(home[i][0]-4,(home[i][1]-4)/8,0xff);
    DisplayByte((home[4][1]-4)/8,home[4][0]-4,0x01);
    DisplayByte((home[4][1]-4)/8,home[4][0]-4+1,0x03);
    DisplayByte((home[4][1]-4)/8,home[4][0]-4+2,0x07);
    DisplayByte((home[4][1]-4)/8,home[4][0]-4+3,0x0F);
    DisplayByte((home[4][1]-4)/8,home[4][0]-4+4,0x1F);
    DisplayByte((home[4][1]-4)/8,home[4][0]-4+5,0x3F);
    DisplayByte((home[4][1]-4)/8,home[4][0]-4+6,0x7F);
    DisplayByte((home[4][1]-4)/8,home[4][0]-4+7,0xFF);

    DisplayByte((home[5][1]-4)/8,home[5][0]-4,0x80);
    DisplayByte((home[5][1]-4)/8,home[5][0]-4+1,0xC0);
    DisplayByte((home[5][1]-4)/8,home[5][0]-4+2,0xE0);
    DisplayByte((home[5][1]-4)/8,home[5][0]-4+3,0xF0);
    DisplayByte((home[5][1]-4)/8,home[5][0]-4+4,0xF8);
    DisplayByte((home[5][1]-4)/8,home[5][0]-4+5,0xFC);
    DisplayByte((home[5][1]-4)/8,home[5][0]-4+6,0xFE);
    DisplayByte((home[5][1]-4)/8,home[5][0]-4+7,0xFF);
		sound();
}