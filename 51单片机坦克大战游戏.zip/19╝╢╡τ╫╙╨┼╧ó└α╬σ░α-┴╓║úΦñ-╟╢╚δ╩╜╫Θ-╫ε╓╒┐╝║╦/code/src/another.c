#include <stdio.h>
#include "reg51.h"
typedef unsigned char  uint8;                   /* defined for unsigned 8-bits integer variable 	无符号8位整型变量  */
sbit key1 = P1^0;
sbit key2 = P1^1;
sbit key3 = P1^2;
sbit key4 = P1^3;
sbit key5 = P1^4;
sbit key6 = P1^5;

int key_1 = 0;
int key_2 = 0;
int key_3 = 0;
int key_4 = 0;

int A=30000;
uint8 flag = 0;
#define UP    1
#define DOWN  2
#define LEFT  3
#define RIGHT 4
#define FIGHT 5
#define STOP  6
void initex(){
		TMOD = 0x20;
	TH1 = 253;
	TL1 = 253;
	TR1 = 1;
	SM0 = 0;
	SM1 = 1;
	EA = 1;
	ES = 1;
}
void delay(unsigned int  z)
{
	unsigned int  x,y;
	for(x = z; x > 0; x--)
		for(y = 114; y > 0 ; y--); 		
} 
void main(){
	initex();
	while(1){
	if(key1 == 0){
		
		delay (20);
		if(key1 == 0){
			
			while(key1 != 1){
				if(flag == 0)
				key_1++;
				if(key_1 == A && TI == 0 && flag == 0){
					SBUF = 11;
					flag = 1;
					//key_1 = 0;
				}
			}
			if(key_1 < A)
				SBUF = UP;
			flag = 0;
			key_1 = 0;	
		}
	}
	if(key2 == 0){
		
		delay (20);
		if(key2 == 0){
			
			while(key2 != 1){
				if(flag == 0)
				key_2++;
				if(key_2 == A && TI == 0 && flag == 0){
					SBUF = 22;
					flag = 1;
					//key_1 = 0;
				}
			}
			if(key_2 < A)
				SBUF = LEFT;
			flag = 0;
			key_2 = 0;	
		}
	}
	if(key3 == 0){
		
		delay (20);
		if(key3 == 0){
			
			while(key3 != 1){
				if(flag == 0)
				key_3++;
				if(key_3 == A && TI == 0 && flag == 0){
					SBUF = 33;
					flag = 1;
					//key_1 = 0;
				}
			}
			if(key_3 < A)
				SBUF = RIGHT;
			flag = 0;
			key_3 = 0;	
		}
	}
	if(key4 == 0){
		
		delay (20);
		if(key4 == 0){
			
			while(key4 != 1){
				if(flag == 0)
				key_4++;
				if(key_4 == A && TI == 0 && flag == 0){
					SBUF = 44;
					flag = 1;
					//key_1 = 0;
				}
			}
			if(key_4 < A)
				SBUF = DOWN;
			flag = 0;
			key_4 = 0;	
		}
	}
	if(key5 == 0){
		delay (20);
		if(key5 == 0){
			while(key5 == 0);
			SBUF = FIGHT;
		}
	}
	if(key6 == 0){	
		delay (20);
		if(key6 == 0){			
			while(!key6);			
			SBUF = STOP;
		}
	}

}
}
void USART_INTR() interrupt 4	//串口中断
{
	if(TI == 1)
	{
		TI = 0;
		
		//Delay1s();
	}
}
	
	