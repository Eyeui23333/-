#include <stdio.h>
#include <reg51.h>
#include <stdlib.h>
#include <intrins.h>
#include "../inc/all.h"
uint8 game_flag = 1;
uint8 last_flag = 0;
uint8 re;
int8 second = 60;
uint8 count = 0;
//int8 data tet;
void init()
{
    SCON = 0x50;
    TMOD = 0x21;//����0/1��ʱ��
		TH0 = 0Xd8;//ʮ��λģʽ 65535-1000=d8f0=10ms
		TL0 = 0xf0;
    TH1 = 253;
    TL1 = 253;
    TR1 = 1;
	  TR0 = 0;
    ES = 1;//�����ж�
		//ET0 = 0;
    EA = 1;
		

}
void main()
{
	
	//uint8 i;for(i=0;i<256;i++){At24c02Write(i,0xFF);delay(10);}
	//while(re!= 0x80);
		
		read();
    init();
    init_lcd();
		isplay2(0);
    display(0);
	CleanAll();
	sound();
	welcome();
	while(re != STOP);
	re = 0;
	sound_pom();
	while(1){
    begin_view();
	while(1){
		if(posit2[0] == 30)
			choose_view();
		if(posit2[0] == 108){
			range_view();//����ҳ���߷���
			break;
		}
		if(posit2[0] == 69 || posit1[0] == 20){
			level_one();
			if(last_flag == 1){
				last_flag = 0;
				break;
			}
			posit1[0] = 42;
	  }
		if(posit1[0] == 42){//������һ�ص�flag��ѡ�񷵻���һ��������ѭ�����ǵû����posit��ֵ
				level_two();
			if(last_flag == 1){
				last_flag = 0;
				break;
			}
			posit1[0] = 64;
		}
		if(posit1[0] == 64){
			level_three();
			if(last_flag == 1){
				last_flag = 0;
				break;
			}
			posit1[0] = 86;
		}
		if(posit1[0] == 86){
			level_four();
			if(last_flag == 1){
				last_flag = 0;
				break;
			}
			posit1[0] = 108;
		}
		if(posit1[0] == 108){
			level_five();
			last_flag = 0;
			break;
		}
	}
	}
}

void level_one(){
       CleanAll();
       fu_view();
       draw_one();
       draw_home();
       level = 1;
       Initialize();
			 re = 0;
       while(game_flag == 1) //������Ϊflag�ĵȴ�
       {		
          design_all();
					range(score,grade1);//�ѷ�������
					//�ϵ�洢
					write();
			 }
       game_flag = 1;
			 score = 0;
 			num_code[0] = 0x3F;
			num_code[1] = 0x3F;
			display(score);
}

void level_two(){
       CleanAll();
       fu_view();
       draw_two();
       draw_home();
       level = 2;
       Initialize();
			 re = 0;
       while(game_flag == 1) //������Ϊflag�ĵȴ�
       {		
          design_all();
					range(score,grade2);//�ѷ�������
					//�ϵ�洢
					write();
			 }
       game_flag = 1;
			 score = 0;
 			num_code[0] = 0x3F;
			num_code[1] = 0x3F;
			display(score);
}
	
void level_three(){
       CleanAll();
       fu_view();
       draw_two();
       draw_home();
       level = 3;
       Initialize();
			 re = 0;
       while(game_flag == 1) //������Ϊflag�ĵȴ�
       {		
          design_all();
					range(score,grade3);//�ѷ�������
					//�ϵ�洢
					write();
			 }
       game_flag = 1;
			 score = 0;
 			num_code[0] = 0x3F;
			num_code[1] = 0x3F;
			display(score);
}

void level_four(){
       CleanAll();
       fu_view();
       draw_two();
       draw_home();
       level = 4;
       Initialize();
			 re = 0;
       while(game_flag == 1) //������Ϊflag�ĵȴ�
       {		
          design_all();
					range(score,grade4);//�ѷ�������
					//�ϵ�洢
					write();
			 }
       game_flag = 1;
			 score = 0;
 			num_code[0] = 0x3F;
			num_code[1] = 0x3F;
			display(score);
}

void level_five(){
       CleanAll();
       fu_view();
       draw_three();
       draw_home();
       level = 5;
       Initialize();
			 re = 0;
       while(game_flag == 1) //������Ϊflag�ĵȴ�
       {		
          design_all();
					range(score,grade5);//�ѷ�������
					//�ϵ�洢
					write();
			 }
       game_flag = 1;
			 score = 0;
 			num_code[0] = 0x3F;
			num_code[1] = 0x3F;
			display(score);
}

void tim() interrupt 1
{
	

	//isplay2(second);
	TH0 = 0xd8;
	TL0 = 0xf0;
	count++;
	if(count == 100){//10ms��ʱ
		count = 0;
		second--;
		if(second == 0){
			game_flag = 0;
			TR0 = 0;
			ET0 = 0;//��ʱ��0����ʱ
			
		}
	isplay2(second);
	}
	
	//TF0 = 0;
}

void scon() interrupt 4
{
    if(RI)
    {
        re = SBUF;
        RI = 0;
    }
}
