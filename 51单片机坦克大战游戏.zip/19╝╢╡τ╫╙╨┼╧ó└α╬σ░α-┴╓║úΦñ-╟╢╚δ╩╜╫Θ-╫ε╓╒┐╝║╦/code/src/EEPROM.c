#include <stdio.h>
#include <reg51.h>
#include <stdlib.h>
#include <intrins.h>
#include "../inc/all.h"
uint8 grade1[4] = 0;
uint8 grade2[4] = 0;
uint8 grade3[4] = 0;
uint8 grade4[4] = 0;
uint8 grade5[4] = 0;
uint8 grade11[4] = 0x00;//����I2C�ķ������ʱ
uint8 grade22[4] = 0x00;
uint8 grade33[4] = 0x00;
uint8 grade44[4] = 0x00;
uint8 grade55[4] = 0x00;
uint8 code Pai[32] =  {0x10,0x10,0x10,0xFF,0x90,0x08,0x88,0x88,0xFF,0x00,0x00,0xFF,0x88,0x88,0x08,0x00,0x02,0x42,0x81,0x7F,0x00,0x08,0x08,0x08,0xFF,0x00,0x00,0xFF,0x08,0x08,0x08,0x00};
uint8 code Hang[32] = {0x00,0x10,0x88,0xC4,0x33,0x00,0x40,0x42,0x42,0x42,0xC2,0x42,0x42,0x42,0x40,0x00,0x02,0x01,0x00,0xFF,0x00,0x00,0x00,0x00,0x40,0x80,0x7F,0x00,0x00,0x00,0x00,0x00};

//uint8 code FHao[16] = {0x00,0x00,0x00,0xC0,0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x30,0x30,0x00,0x00,0x00}; //8*8
uint8 code num00[8] = {0xE0,0x18,0x18,0xE0,0x0F,0x30,0x30,0x0F};
uint8 code num11[8] = {0x00,0x00,0xF0,0x00,0x00,0x20,0x3F,0x00};
uint8 code num22[8] = {0x30,0x08,0x88,0x70,0x30,0x2C,0x23,0x18};
uint8 code num33[8] = {0x10,0x08,0xD8,0x20,0x18,0x20,0x31,0x0E};
uint8 code num44[8] = {0x00,0xC0,0xF8,0x00,0x07,0x04,0x3F,0x24};
uint8 code num55[8] = {0x70,0x88,0x88,0x00,0x18,0x20,0x30,0x0F};
uint8 code num66[8] = {0xE0,0x98,0x88,0x00,0x0F,0x30,0x20,0x1F};
uint8 code num77[8] = {0x30,0x08,0xE8,0x18,0x00,0x3E,0x01,0x00};
uint8 code num88[8] = {0x70,0x88,0x88,0x70,0x1E,0x21,0x23,0x1C};
uint8 code num99[8] = {0xF0,0x08,0x18,0xE0,0x01,0x22,0x19,0x07};

uint8 code zw1[32] = {0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};/*"һ",0*/

uint8 code zw2[32] = {0x00,0x00,0x08,0x08,0x08,0x08,0x08,0x08,0x08,0x08,0x08,0x08,0x08,0x00,0x00,0x00,
0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x00};/*"��",1*/

uint8 code zw3[32] = {0x00,0x04,0x84,0x84,0x84,0x84,0x84,0x84,0x84,0x84,0x84,0x84,0x84,0x04,0x00,0x00,
0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x00};/*"��",2*/

uint8 code zw4[32] = {0x00,0xFC,0x04,0x04,0x04,0xFC,0x04,0x04,0x04,0xFC,0x04,0x04,0x04,0xFC,0x00,0x00,
0x00,0x7F,0x28,0x24,0x23,0x20,0x20,0x20,0x20,0x21,0x22,0x22,0x22,0x7F,0x00,0x00};/*"��",3*/

uint8 code zw5[32] = {0x00,0x02,0x42,0x42,0x42,0xC2,0x7E,0x42,0x42,0x42,0x42,0xC2,0x02,0x02,0x00,0x00,
0x40,0x40,0x40,0x40,0x78,0x47,0x40,0x40,0x40,0x40,0x40,0x7F,0x40,0x40,0x40,0x00};/*"��",4*/
uint8 code Fen[32] ={0x80,0x40,0x20,0x90,0x88,0x86,0x80,0x80,0x80,0x83,0x8C,0x10,0x20,0x40,0x80,0x00,
0x00,0x80,0x40,0x20,0x18,0x07,0x00,0x40,0x80,0x40,0x3F,0x00,0x00,0x00,0x00,0x00};/*"��",0*/

uint8 eeprom;
void read(){
	
	uint8 i,k=0;
	eeprom = At24c02Read(30);delay(5);
	if(eeprom != 0x30){
		for(i=0;i<4;i++)
			grade1[i] = 0;
		for(i=0;i<4;i++)
			grade2[i] = 0;
		for(i=0;i<4;i++)
			grade3[i] = 0;
		for(i=0;i<4;i++)
			grade4[i] = 0;
		for(i=0;i<4;i++)
			grade5[i] = 0;
		//while(re != 0x80);re = 0;
		return;
	}
	for(i=0;i<4;i++){
		grade1[i] = At24c02Read(i+1);
		delay(10);}
	for(i=0;i<4;i++){
		grade2[i] = At24c02Read(i+5);
	delay(10);} 
	for(i=0;i<4;i++){
		grade3[i] = At24c02Read(i+9);
	delay(10);}
	for(i=0;i<4;i++){
		grade4[i] = At24c02Read(i+13);
	delay(10);}
	for(i=0;i<4;i++){
		grade5[i] = At24c02Read(i+17);
	delay(10);}

}
	
void write(){
	uint8 i;
  eeprom = 0x30;
	//��ʱ���ݴ���
	for(i=0;i<4;i++)
	grade11[i] = grade1[i];
	for(i=0;i<4;i++)
	grade22[i] = grade2[i];
	for(i=0;i<4;i++)
	grade33[i] = grade3[i];
	for(i=0;i<4;i++)
	grade44[i] = grade4[i];
	for(i=0;i<4;i++)
	grade55[i] = grade5[i];
	
	for(i=0;i<4;i++){
		At24c02Write(i+1,grade11[i]);
		delay(10);
	}

	for(i=0;i<4;i++){
		At24c02Write(i+5,grade22[i]);
		delay(10);
	}
	for(i=0;i<4;i++){
		At24c02Write(i+9,grade33[i]);
		delay(10);
	}
	for(i=0;i<4;i++){
		At24c02Write(i+13,grade44[i]);
		delay(10);
	}
	for(i=0;i<4;i++){
		At24c02Write(i+17,grade55[i]);
		delay(10);
	}
	delay(10);
	At24c02Write(30,eeprom);
}
		

		
//AT24C02
void At24c02Write(uint8 addr,uint8 dat)
{
	I2C_Start();
	I2C_SendByte(0xa0, 1);//����д������ַ
	I2C_SendByte(addr, 1);//����Ҫд���ڴ��ַ
	I2C_SendByte(dat, 0);	//��������
	I2C_Stop();
}

uint8 At24c02Read(uint8 addr)
{
	uint8 num;
	I2C_Start();
	I2C_SendByte(0xa0, 1); //����д������ַ
	I2C_SendByte(addr, 1); //����Ҫ��ȡ�ĵ�ַ
	I2C_Start();
	I2C_SendByte(0xa1, 1); //���Ͷ�������ַ
	num=I2C_ReadByte(); //��ȡ����
	I2C_Stop();
	return num;	
}

//I2Cģ��
void I2C_Delay10us()
{
	uint8 a, b;
	for(b=1; b>0; b--)
	{
		for(a=2; a>0; a--);
	}
}
	
void I2C_Start()
{
	I2C_SDA = 1;
	I2C_Delay10us();
	I2C_SCL = 1;
	I2C_Delay10us();//����ʱ����I2C_SDA����ʱ��>4.7us
	I2C_SDA = 0;
	I2C_Delay10us();//����ʱ����>4us
	I2C_SCL = 0;			
	I2C_Delay10us();		
}

void I2C_Stop()
{
	I2C_SDA = 0;
	I2C_Delay10us();
	I2C_SCL = 1;
	I2C_Delay10us();//����ʱ�����4.7us
	I2C_SDA = 1;
	I2C_Delay10us();		
}
	
uint8 I2C_SendByte(uint8 dat, uint8 ack)
{
	uint8 a = 0,b = 0;//���255��һ����������Ϊ1us�������ʱ255us��
			
	for(a=0; a<8; a++)//Ҫ����8λ�������λ��ʼ
	{
		I2C_SDA = dat >> 7;	 //��ʼ�ź�֮��I2C_SCL=0�����Կ���ֱ�Ӹı�I2C_SDA�ź�
		dat = dat << 1;
		I2C_Delay10us();
		I2C_SCL = 1;
		I2C_Delay10us();//����ʱ��>4.7us
		I2C_SCL = 0;
		I2C_Delay10us();//ʱ�����4us		
	}

	I2C_SDA = 1;
	I2C_Delay10us();
	I2C_SCL = 1;
	while(I2C_SDA && (ack == 1))//�ȴ�Ӧ��Ҳ���ǵȴ����豸��I2C_SDA����
	{
		b++;
		/*
		if(b > 200)	 //�������200usû��Ӧ����ʧ�ܣ�����Ϊ��Ӧ�𣬱�ʾ���ս���
		{
			I2C_SCL = 0;
			I2C_Delay10us();
			while(re!= 0x80);
			return 0;
		}*/
	}

	I2C_SCL = 0;
	I2C_Delay10us();
 	return 1;		
}

uint8 I2C_ReadByte()
{
	uint8 a = 0,dat = 0;
	I2C_SDA = 1;			//��ʼ�ͷ���һ���ֽ�֮��I2C_SCL����0
	I2C_Delay10us();
	for(a=0; a<8; a++)//����8���ֽ�
	{
		I2C_SCL = 1;
		I2C_Delay10us();
		dat <<= 1;
		dat |= I2C_SDA;
		I2C_Delay10us();
		I2C_SCL = 0;
		I2C_Delay10us();
	}
	return dat;		
}
//����score���ж����������Ƿ�������0���������룬������Ϊ0��Ԫ�أ�Ȼ������
//�����һ�������ĸ��Ļ����Ͱ����һ������score��
//Ȼ���ٽ�������
 void range(uint8 grade,uint8 *array){
	 uint8 i,j,tp,k=0;
	 if(grade == 0)
		 return;
		for(i=0;i<4;i++){
		 if(array[i] != 0){
			 k++;
		 }
		}
	 if(k == 0){
		 array[0] = grade;
		 return;
	 }
	 if(k < 4){
		 array[k] = grade;
		 for(i=0;i<k;i++){//ð������
			 for(j=0;j<k-i;j++){
				 if(array[j] < array[j+1]){
					 tp = array[j];
					 array[j] = array[j+1];
					 array[j+1] = tp;
				 }
				}
			}
		}
	 else if(k == 4){
		 if(array[k-1] > grade)//����δ��
			 return;
	 }
		 else{
			 array[k-1] = grade;
		 for(i=0;i<3;i++){//ð������
			 for(j=0;j<3-i;j++){
				 if(array[j] < array[j+1]){
					 tp = array[j];
					 array[j] = array[j+1];
					 array[j+1] = tp;
				 }
				}
			}
		}
}
void range_view(){//����ҳ���߷���
	CleanAll();
	LCDMcs=0; //��������ʾ
  LCDScs=1;
	Display_hz(1,20,Didi);
	Display_hz(3,20,zw1);
	Display_hz(5,20,Guan);
	Display_num(0,56,num11);//����
	Display_num(2,56,num22);
	Display_num(4,56,num33);
	Display_num(6,56,num44);
	range_operate(grade1);
	while(re != RIGHT){
		if(re == STOP){
			sound_pom();
			re = 0;
			return;
	}
		
}
	sound_pom();
	re = 0;
	CleanAll();
	LCDMcs=0; //��������ʾ
  LCDScs=1;
	Display_hz(1,20,Didi);
	Display_hz(3,20,zw2);
	Display_hz(5,20,Guan);
	Display_num(0,56,num11);//����
	Display_num(2,56,num22);
	Display_num(4,56,num33);
	Display_num(6,56,num44);
	range_operate(grade2);
	while(re != RIGHT){
		if(re == STOP){
			sound_pom();
			re = 0;
			return;
		}
		
	}
	sound_pom();
	re = 0;
	CleanAll();
	LCDMcs=0; //��������ʾ
  LCDScs=1;
	Display_hz(1,20,Didi);
	Display_hz(3,20,zw3);
	Display_hz(5,20,Guan);
	Display_num(0,56,num11);//����
	Display_num(2,56,num22);
	Display_num(4,56,num33);
	Display_num(6,56,num44);
	range_operate(grade3);
	while(re != RIGHT){
		if(re == STOP){
			re = 0;
			sound_pom();
			return;
		}
		
	}
	sound_pom();
	re = 0;
	CleanAll();
	LCDMcs=0; //��������ʾ
  LCDScs=1;
	Display_hz(1,20,Didi);
	Display_hz(3,20,zw4);
	Display_hz(5,20,Guan);
	Display_num(0,56,num11);//����
	Display_num(2,56,num22);
	Display_num(4,56,num33);
	Display_num(6,56,num44);
	range_operate(grade4);
	while(re != RIGHT){
		if(re == STOP){
			sound_pom();
			re = 0;
			sound_pom();
			return;
		}
		
	}
	sound_pom();
	re = 0;
	CleanAll();
	LCDMcs=0; //��������ʾ
  LCDScs=1;
	Display_hz(1,20,Didi);
	Display_hz(3,20,zw5);
	Display_hz(5,20,Guan);
	Display_num(0,56,num11);//����
	Display_num(2,56,num22);
	Display_num(4,56,num33);
	Display_num(6,56,num44);
	range_operate(grade5);
	while(re != RIGHT && re != STOP);
	re = 0;
	sound_pom();
}
	
	
void range_operate(uint8 *array){
	
	uint8 i,t1,t2;

	LCDMcs=1; //��������ʾ
	LCDScs=0;
	for(i=0;i<4;i++){
		if(array[i] == 0)
			break;
		if(array[i] < 10){
			switch(array[i]){
				case 1:Display_num(2*i,20,num11);break;
				case 2:Display_num(2*i,20,num22);break;
				case 3:Display_num(2*i,20,num33);break;
				case 4:Display_num(2*i,20,num44);break;
				case 5:Display_num(2*i,20,num55);break;
				case 6:Display_num(2*i,20,num66);break;
				case 7:Display_num(2*i,20,num77);break;
				case 8:Display_num(2*i,20,num88);break;
				case 9:Display_num(2*i,20,num99);break;
			}
		}
		if(array[i] >= 10){
			t1 =array[i] % 10;
			t2 = array[i] / 10;
			switch(t1){//��λ��
				case 0:Display_num(2*i,25,num00);break;
				case 1:Display_num(2*i,25,num11);break;
				case 2:Display_num(2*i,25,num22);break;
				case 3:Display_num(2*i,25,num33);break;
				case 4:Display_num(2*i,25,num44);break;
				case 5:Display_num(2*i,25,num55);break;
				case 6:Display_num(2*i,25,num66);break;
				case 7:Display_num(2*i,25,num77);break;
				case 8:Display_num(2*i,25,num88);break;
				case 9:Display_num(2*i,25,num99);break;
			}
			switch(t2){
				case 1:Display_num(2*i,20,num11);break;
				case 2:Display_num(2*i,20,num22);break;
				case 3:Display_num(2*i,20,num33);break;
				case 4:Display_num(2*i,20,num44);break;
				case 5:Display_num(2*i,20,num55);break;
				case 6:Display_num(2*i,20,num66);break;
				case 7:Display_num(2*i,20,num77);break;
				case 8:Display_num(2*i,20,num88);break;
				case 9:Display_num(2*i,20,num99);break;
			}	
		}
	}
	Display_hz(3,30,Fen);
	display_tou(102,52);
	
}
void display_tou(uint8 ucCol,uint8 ucPage){
	uint8 temp;
	ucCol = ucCol - 4;
	temp = (ucPage - 4)/8;
	DisplayByte(temp,ucCol,0xFF);
	DisplayByte(temp,ucCol+1,0xFF);
	DisplayByte(temp,ucCol+2,0xFF);
	DisplayByte(temp,ucCol+3,0x7E);
	DisplayByte(temp,ucCol+4,0x3C);
	DisplayByte(temp,ucCol+5,0x18);
	DisplayByte(temp,ucCol+6,0x18);
	DisplayByte(temp,ucCol+7,0x18);
}

void display_tou2(uint8 ucCol,uint8 ucPage){
	uint8 temp;
	ucCol = ucCol - 4;
	temp = (ucPage - 4)/8;
	DisplayByte(temp,ucCol,~0xFF);
	DisplayByte(temp,ucCol+1,~0xFF);
	DisplayByte(temp,ucCol+2,~0xFF);
	DisplayByte(temp,ucCol+3,~0x7E);
	DisplayByte(temp,ucCol+4,~0x3C);
	DisplayByte(temp,ucCol+5,~0x18);
	DisplayByte(temp,ucCol+6,~0x18);
	DisplayByte(temp,ucCol+7,~0x18);
}
	 
			 