#include <stdio.h>
#include <reg51.h>
#include <stdlib.h>
#include <intrins.h>
#include "../inc/all.h"
uint8 TankCheak(Tank tank)
{
    if(tank.direction == UP && tank.y == 4)
        return 1;
    if(tank.direction == DOWN && tank.y == 60)
        return 1;
    if(tank.direction == RIGHT && tank.x == 92)
        return 1;
    if(tank.direction == LEFT && tank.x == 4)
        return 1;

    if(tank.my ==1)
    {
        if(find_AI(tank.x,tank.y,tank.direction) == 1)
            return 1;
    }
    if(tank.my == 0)
    {
        if(find_AI(tank.x,tank.y,tank.direction) == 1)
            return 1;
        if(find_me(tank.x,tank.y,tank.direction) == 1)
            return 1;
    }
    if(find_brick(tank.x,tank.y,tank.direction) != 0)
        return 1;
    return 0;//��ͨ��
}
uint8 find_brick(uint8 x,uint8 y,uint8 direction)
{
    uint8 i,j=0;
    if(direction == LEFT)
    {
			for(i=0; i<4; i++)
        {
            if((y == home[i][j+1] || y == home[i][j+1]+1 || y == home[i][j+1]-1 || y == home[i][j+1]+2 || y == home[i][j+1]-2 || y == home[i][j+1]+3 || y == home[i][j+1]-3) && home[i][j+1] != 0)
            {
                if( x == home[i][j]+8 || x == home[i][j])
                {
                    home_i = i;
                    return 4;
                }
            }
        }
        for(i=4; i<6; i++) //Ŀ��λ�õ��ж�
        {
            if((y == home[i][j+1] || y == home[i][j+1]+1 || y == home[i][j+1]-1 || y == home[i][j+1]+2 || y == home[i][j+1]-2 || y == home[i][j+1]+3 || y == home[i][j+1]-3) && home[i][j+1] != 0)
            {
                if(x == home[i][j]+8 || x == home[i][j])
                    return 5;
            }
        }
        if(x <= 4 || x>92)
            return 3;
        for(i=0; i<8; i++)
        {
            if((y == brick[i][j+1] || y == brick[i][j+1] +1 || y == brick[i][j+1]-1 || y == brick[i][j+1]+2 || y == brick[i][j+1]-2 || y == brick[i][j+1]+3 || y == brick[i][j+1]-3) && brick[i][j+1] != 0)
            {
                if(x == brick[i][j]+8 || x == brick[i][j])
                {
                    brick_i = i;
                    return 1;
                }
            }
        }
        
        for(i=0; i<4; i++)
        {
            if((y == steel[i][j+1] || y == steel[i][j+1] +1 || y == steel[i][j+1]-1 || y == steel[i][j+1]+2 || y == steel[i][j+1]-2 || y == steel[i][j+1]+3 || y == steel[i][j+1]-3) && steel[i][j+1] != 0)
            {
                if( x == steel[i][j]+8 || x == steel[i][j])
                {
                    steel_i = i;
                    return 2;
                }
            }
        }
    }
    if(direction == RIGHT)
    {
			   for(i=0; i<4; i++)
        {
            if((y == home[i][j+1] || y == home[i][j+1]+1 || y == home[i][j+1]-1 || y == home[i][j+1]+2 || y == home[i][j+1]-2 || y == home[i][j+1]+3 || y == home[i][j+1]-3) && home[i][j+1] != 0)
            {
                if( x == home[i][j]-8 || x == home[i][j])
                {
                    home_i = i;
                    return 4;
                }
            }
        }
        for(i=4; i<6; i++) //Ŀ��λ�õ��ж�
        {
            if((y == home[i][j+1] || y == home[i][j+1]+1 || y == home[i][j+1]-1 || y == home[i][j+1]+2 || y == home[i][j+1]-2 || y == home[i][j+1]+3 || y == home[i][j+1]-3) && home[i][j+1] != 0)
            {
                if(x == home[i][j]-8 || x == home[i][j])
                    return 5;
            }
        }
        if(x >= 92 || x<4)
            return 3;
        for(i=0; i<8; i++)
        {
            if((y == brick[i][j+1] || y == brick[i][j+1] +1 || y == brick[i][j+1]-1 || y == brick[i][j+1]+2 || y == brick[i][j+1]-2 || y == brick[i][j+1]+3 || y == brick[i][j+1]-3) && brick[i][j+1] != 0)
            {
                if(x == brick[i][j]-8 || x == brick[i][j])
                {
                    brick_i = i;
                    return 1;
                }
            }
        }

        for(i=0; i<4; i++)
        {
            if((y == steel[i][j+1] || y == steel[i][j+1] +1 || y == steel[i][j+1]-1 || y == steel[i][j+1]+2 || y == steel[i][j+1]-2 || y == steel[i][j+1]+3 || y == steel[i][j+1]-3) && steel[i][j+1] != 0)
            {
                if( x == steel[i][j]-8 || x == steel[i][j])
                {
                    steel_i = i;
                    return 2;
                }
            }
        }
    }
    if(direction == UP)
    {
        for(i=0; i<4; i++)
        {
            if((x == home[i][j] || x == home[i][j]+1 || x == home[i][j]-1 || x == home[i][j]+2 || x == home[i][j]-2 || x == home[i][j]+3 || x == home[i][j]-3) && home[i][j] != 0)
            {
                if( y == home[i][j+1]+8 || y == home[i][j+1])
                {
                    home_i = i;
                    return 4;
                }
            }
        }
        for(i=4; i<6; i++)
        {
            if((x == home[i][j] || x == home[i][j]+1 || x == home[i][j]-1 || x == home[i][j]+2 || x == home[i][j]-2 || x == home[i][j]+3 || x == home[i][j]-3) && home[i][j] != 0)
            {
                if( y == home[i][j+1]+8 || y == home[i][j+1])
                    return 5;
            }
        }
        if( y > 60 || y<=4)
            return 3;
        for(i=0; i<8; i++)
        {
            if((x == brick[i][j] || x == brick[i][j]+1 || x == brick[i][j]-1 || x == brick[i][j]+2 || x == brick[i][j]-2 || x == brick[i][j]+3 || x == brick[i][j]-3) && brick[i][j] != 0)
            {
                if(y == brick[i][j+1]+8 || y == brick[i][j+1])
                {
                    brick_i = i;
                    return 1;
                }
            }
        }

        for(i=0; i<4; i++)
        {
            if((x == steel[i][j] || x == steel[i][j]+1 || x == steel[i][j]-1 || x == steel[i][j]+2 || x == steel[i][j]-2 || x == steel[i][j]+3 || x == steel[i][j]-3) && steel[i][j] != 0)
            {
                if( y == steel[i][j+1]+8 || y == steel[i][j+1])
                {
                    steel_i = i;
                    return 2;
                }
            }
        }
    }
    if(direction == DOWN)
    {
        for(i=0; i<4; i++)
        {
            if((x == home[i][j] || x == home[i][j]+1 || x == home[i][j]-1 || x == home[i][j]+2 || x == home[i][j]-2 || x == home[i][j]+3 || x == home[i][j]-3) && home[i][j] != 0)
            {
                if( y == home[i][j+1]-8 || y == home[i][j+1])
                {
                    home_i = i;
                    return 4;
                }
            }
        }
        for(i=4; i<6; i++)
        {
            if((x == home[i][j] || x == home[i][j]+1 || x == home[i][j]-1 || x == home[i][j]+2 || x == home[i][j]-2 || x == home[i][j]+3 || x == home[i][j]-3) && home[i][j] != 0)
            {
                if( y == home[i][j+1]-8 || y == home[i][j+1])
                    return 5;
            }
        }
        if(y < 4 || y>=60)
            return 3;
        //if( y >= 60)
        for(i=0; i<8; i++)
        {
            if((x == brick[i][j] || x == brick[i][j]+1 || x == brick[i][j]-1 || x == brick[i][j]+2 || x == brick[i][j]-2 || x == brick[i][j]+3 || x == brick[i][j]-3) && brick[i][j] != 0)
            {
                if(y == brick[i][j+1]-8 || y == brick[i][j+1])
                {
                    brick_i = i;
                    return 1;
                }
            }
        }

        for(i=0; i<4; i++)
        {
            if((x == steel[i][j] || x == steel[i][j]+1 || x == steel[i][j]-1 || x == steel[i][j]+2 || x == steel[i][j]-2 || x == steel[i][j]+3 || x == steel[i][j]-3) && steel[i][j] != 0)
            {
                if( y == steel[i][j+1]-8 || y == steel[i][j+1])
                {
                    steel_i = i;
                    return 2;
                }
            }
        }
    }
    return 0;
}

uint8 find_me(uint8 x,uint8 y,uint8 direction)
{
    if(my_tank.alive == 1)
    {
        if(direction == RIGHT)
        {
            if(y == my_tank.y || y == my_tank.y+1 || y == my_tank.y+2  || y == my_tank.y+3 || y == my_tank.y-1 || y == my_tank.y-2 || y == my_tank.y-3)
                if(x == my_tank.x -8 || x == my_tank.x )
                {
                    return 1;
                }
        }
        if(direction == LEFT)
        {
            if(y == my_tank.y || y == my_tank.y+1 || y == my_tank.y+2  || y == my_tank.y+3 || y == my_tank.y-1 || y == my_tank.y-2 || y == my_tank.y-3)
                if(x == my_tank.x +8 || x == my_tank.x)
                {
                    return 1;
                }
        }
        if(direction == UP)
        {
            if(x == my_tank.x || x == my_tank.x+1 || x == my_tank.x+2  || x == my_tank.x+3 || x == my_tank.x-1 || x == my_tank.x-2 || x == my_tank.x-3)
                if(y ==  my_tank.y +8 || y ==  my_tank.y)
                {
                    return 1;
                }
        }
        if(direction == DOWN)
        {
            if(x == my_tank.x || x ==my_tank.x+1 || x ==my_tank.x+2  || x == my_tank.x+3 || x == my_tank.x-1 || x == my_tank.x-2 || x == my_tank.x-3)
                if(y == my_tank.y -8 || y == my_tank.y)
                {
                    return 1;
                }
        }
    }
    return 0;
}

uint8 find_AI(uint8 x,uint8 y,uint8 direction)
{
    uint8 i;
    for(i = 0; i<4; i++)
    {
        if(AI_tank[i].alive == 1)
        {
            if(y == AI_tank[i].y && x == AI_tank[i].x)
                continue;
            if(direction == RIGHT)
            {
                if(y == AI_tank[i].y || y == AI_tank[i].y+1 || y == AI_tank[i].y+2  || y == AI_tank[i].y+3 || y == AI_tank[i].y-1 || y == AI_tank[i].y-2 || y == AI_tank[i].y-3)
                    if(x == AI_tank[i].x - 8 || x == AI_tank[i].x )
                    {
                        AI_tank_i = i;
                        return 1;
                    }
            }
            if(direction == LEFT)
            {
                if(y == AI_tank[i].y || y == AI_tank[i].y+1 || y == AI_tank[i].y+2  || y == AI_tank[i].y+3 || y == AI_tank[i].y-1 || y == AI_tank[i].y-2 || y == AI_tank[i].y-3)
                    if(x == AI_tank[i].x +8 || x == AI_tank[i].x)
                    {
                        AI_tank_i = i;
                        return 1;
                    }
            }
            if(direction == UP)
            {
                if(x == AI_tank[i].x || x == AI_tank[i].x+1 || x == AI_tank[i].x+2  || x == AI_tank[i].x+3 || x == AI_tank[i].x-1 || x == AI_tank[i].x-2 || x == AI_tank[i].x-3)
                    if(y == AI_tank[i].y +8 || y == AI_tank[i].y)
                    {
                        AI_tank_i = i;
                        return 1;
                    }
            }
            if(direction == DOWN)
            {
                if(x == AI_tank[i].x || x == AI_tank[i].x+1 || x == AI_tank[i].x+2  || x == AI_tank[i].x+3 || x == AI_tank[i].x-1 || x == AI_tank[i].x-2 || x == AI_tank[i].x-3)
                    if(y == AI_tank[i].y -8 || y == AI_tank[i].y)
                    {
                        AI_tank_i = i;
                        return 1;
                    }
            }
        }
    }
    return 0;
}
uint8 bullet_check(uint8 x1,uint8 y1,uint8 direct1,uint8 x2,uint8 y2,uint8 direct2)
{
    if(direct1 == direct2)
        return 0;
    if((direct1 == UP && y2 > y1 ) || (direct1 == DOWN && y2 < y1) || direct1 == RIGHT && x2 < x1 || direct1 == LEFT && x2 > x1)
        return 0;
    if(direct1 == RIGHT || direct1 == LEFT)
    {
        if(y1 == y2 || y1 == y2+1 || y1 == y2+2  || y1 == y2+3 || y1 == y2-1 || y1 == y2-2 || y1 == y2-3)
        {
            if(x1 == x2 +8 || x1 == x2 -8 || x1 == x2)
                return 1;
        }
    }
    if(direct1 == UP || direct1 == DOWN)
    {
        if(x1 == x2 || x1 == x2 +1 || x1 == x2 +2  || x1 == x2 +3 || x1 == x2 -1 || x1 == x2 -2 || x1 == x2 -3)
        {
            if(y1 == y2 +8 || y1 == y2 -8 || y1 == y2)
            {
                return 1;
            }
        }
    }
    return 0;
}